try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

config = {
    'description': 'First knowledge about Single Linked Lists',
    'author': 'Elena',
    'version': '0.1',
    'name': 'Single Linked Lists Project'
}

setup(**config)